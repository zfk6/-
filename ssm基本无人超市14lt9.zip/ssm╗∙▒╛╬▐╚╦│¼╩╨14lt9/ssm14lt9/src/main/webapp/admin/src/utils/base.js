const base = {
    get() {
        return {
            url : "http://localhost:8080/ssm14lt9/",
            name: "ssm14lt9",
            // 退出到首页链接
            indexUrl: 'http://localhost:8080/ssm14lt9/front/index.html'
        };
    },
    getProjectName(){
        return {
            projectName: "基本无人超市"
        } 
    }
}
export default base
