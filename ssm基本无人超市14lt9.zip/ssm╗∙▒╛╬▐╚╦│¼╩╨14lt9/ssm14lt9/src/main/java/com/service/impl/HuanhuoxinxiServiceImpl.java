package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.HuanhuoxinxiDao;
import com.entity.HuanhuoxinxiEntity;
import com.service.HuanhuoxinxiService;
import com.entity.vo.HuanhuoxinxiVO;
import com.entity.view.HuanhuoxinxiView;

@Service("huanhuoxinxiService")
public class HuanhuoxinxiServiceImpl extends ServiceImpl<HuanhuoxinxiDao, HuanhuoxinxiEntity> implements HuanhuoxinxiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<HuanhuoxinxiEntity> page = this.selectPage(
                new Query<HuanhuoxinxiEntity>(params).getPage(),
                new EntityWrapper<HuanhuoxinxiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<HuanhuoxinxiEntity> wrapper) {
		  Page<HuanhuoxinxiView> page =new Query<HuanhuoxinxiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<HuanhuoxinxiVO> selectListVO(Wrapper<HuanhuoxinxiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public HuanhuoxinxiVO selectVO(Wrapper<HuanhuoxinxiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<HuanhuoxinxiView> selectListView(Wrapper<HuanhuoxinxiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public HuanhuoxinxiView selectView(Wrapper<HuanhuoxinxiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
