package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.HuanhuoxinxiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.HuanhuoxinxiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.HuanhuoxinxiView;


/**
 * 换货信息
 *
 * @author 
 * @email 
 * @date 2022-08-05 19:59:28
 */
public interface HuanhuoxinxiService extends IService<HuanhuoxinxiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<HuanhuoxinxiVO> selectListVO(Wrapper<HuanhuoxinxiEntity> wrapper);
   	
   	HuanhuoxinxiVO selectVO(@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);
   	
   	List<HuanhuoxinxiView> selectListView(Wrapper<HuanhuoxinxiEntity> wrapper);
   	
   	HuanhuoxinxiView selectView(@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<HuanhuoxinxiEntity> wrapper);
   	

}

