package com.dao;

import com.entity.HuanhuoxinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.HuanhuoxinxiVO;
import com.entity.view.HuanhuoxinxiView;


/**
 * 换货信息
 * 
 * @author 
 * @email 
 * @date 2022-08-05 19:59:28
 */
public interface HuanhuoxinxiDao extends BaseMapper<HuanhuoxinxiEntity> {
	
	List<HuanhuoxinxiVO> selectListVO(@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);
	
	HuanhuoxinxiVO selectVO(@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);
	
	List<HuanhuoxinxiView> selectListView(@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);

	List<HuanhuoxinxiView> selectListView(Pagination page,@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);
	
	HuanhuoxinxiView selectView(@Param("ew") Wrapper<HuanhuoxinxiEntity> wrapper);
	

}
